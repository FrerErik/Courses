package model.persistence;

/** */
public interface Persistence {
  void load();

  void save();
}
