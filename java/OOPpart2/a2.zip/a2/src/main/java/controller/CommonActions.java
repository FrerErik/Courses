package controller;

/** */
public interface CommonActions {
  void add();

  void delete();

  void update();

  void showDetails();
}
