package controller;

import java.util.ArrayList;

import model.domain.Member;
import view.Console;
import view.MemberOption;

public class TestController {
  private ArrayList<Member> members = new ArrayList<Member>();
  private MemberOption choice;

  public void runMenu(Console c) {
    while (true) {
      for (Member member : members) {
        System.out.println(member.getFirstName());
      }
      choice = c.DisplayMenu();

      if (choice.equals(MemberOption.AddNewMember)) {
        Member newMember = new Member();
        String[] member = c.AddMemberOption().split(", ");
        newMember.setFirstName(member[0]);
        newMember.setLastName(member[1]);
        newMember.setPersonNum(member[2]);
        newMember.setMemberId(Integer.parseInt(member[3]));
        addNewMember(newMember, members);

      } else if (choice.equals(MemberOption.ShowMemberList)) {
        System.out.println("b");
      } else if (choice.equals(MemberOption.PickAMember)) {
        System.out.println("c");
      } else if (choice.equals(MemberOption.Quit)) {
        System.out.println("d");
        break;
      } else if (choice.equals(MemberOption.Error)) {
        System.out.println("e");
      }
    }

  }

  public void addNewMember(Member newMember, ArrayList<Member> members) {
    members.add(newMember);
    System.out.println("member added");
  }
}
