package controller;

import model.domain.Boat;
import model.domain.BoatType;
import model.domain.Member;
import model.domain.Registry;
import view.Console;
import view.MemberBoatUI;
import view.MemberOption;

import java.io.IOException;
import java.util.ArrayList;

public class RegistryController implements Registry.IEventListener {
  MemberBoatUI uI;
  Registry reg;
  Console con;
  Member curMember;
  Boat curBoat;

  public RegistryController(Registry reg, MemberBoatUI uI, Console con) {
    this.reg = reg;
    this.uI = uI;
    this.con = con;
    curMember = null;
    curBoat = null;
  }

  // public void handleMembers(Registry reg, Console con) throws IOException {

  // reg.addEventListener(this);
  // boolean done = false;
  // while (!done) {
  // MemberOption choice = con.getChoosing();
  // switch (choice) {
  // case AddNewMember:
  // addMember(con.getTestID(), con.getFirstName(), con.getLastName(),
  // con.getPersonNum());
  // break;
  // case Quit:
  // default:
  // done = true;
  // break;
  // }
  // }
  // reg.removeEventListener(this);
  // }

  // Will search in registry and return whether it found it or not
  public boolean setCurMember(int memberID) {
    for (Member mem : reg.getMembers()) {
      if (mem.getMemberId() == memberID) {
        curMember = mem;
        return true;
      }
    }

    return false;
  }

  public boolean setCurBoat(int boatID) {
    for (Boat boat : curMember.getBoats()) {
      if (boat.getId() == boatID) {
        curBoat = boat;
        return true;
      }
    }

    return false;
  }

  public void clearCurMember() {
    curMember = null;
  }

  public void clearCurBoat() {
    curBoat = null;
  }

  public void addMember(int memberId, String firstName, String lastName, String personNum) {
    reg.addNewMember(memberId, firstName, lastName, personNum, new ArrayList<Boat>());
  }

  public void addBoat(String name, int id, BoatType type, double length) {
    curMember.getBoats().add(new Boat(name, id, type, length));
  }

  public void deleteCurMember() {
    // reg.getMembers().remove(curMember);
  }

  public void deleteCurBoat() {
    curMember.getBoats().remove(curBoat);
  }

  public void changeMemberInformation(int memberId, String firstName, String lastName, String personNum) {
    curMember.setMemberId(memberId);
    curMember.setFirstName(firstName);
    curMember.setLastName(lastName);
    curMember.setPersonNum(personNum);
  }

  public void changeBoatInformation(String name, int id, BoatType type, double length) {
    curBoat.setName(name);
    curBoat.setId(id);
    curBoat.setType(type);
    curBoat.setLength(length);
  }

  @Override
  public void onAddNewMember(Iterable<Member> a_allMembers, Member a_member) {
    // TODO Auto-generated method stub

  }

  @Override
  public void onAddNewBoat(Iterable<Boat> a_allBoats, Boat b) {
    // TODO Auto-generated method stub

  }

  @Override
  public void onUpdateMember(Member a_oldMember, Member a_newMember) {
    // TODO Auto-generated method stub

  }

  @Override
  public void onUpdateBoat(Member m, Boat a_newBoat) {
    // TODO Auto-generated method stub

  }

  @Override
  public void onDeleteMember(Member a_deleteMember) {
    // TODO Auto-generated method stub

  }

  @Override
  public void onDeleteBoat(Member m, Boat a_deleteboat) {
    // TODO Auto-generated method stub

  }

}