package controller;

import view.Console;

public class App {

  public static void main(String[] args) {
    Console UI = new Console();
    TestController controller = new TestController();
    controller.runMenu(UI);
  }
}
