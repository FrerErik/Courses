package view;

public enum ListOption {
  SimpleList, VerboseList, Error;
}
