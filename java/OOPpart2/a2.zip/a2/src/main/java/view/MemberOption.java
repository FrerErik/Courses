package view;

public enum MemberOption {
  AddNewMember, ShowMemberList, PickAMember, Quit, Error;
}
