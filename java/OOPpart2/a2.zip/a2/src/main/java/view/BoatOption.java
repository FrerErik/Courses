package view;

public enum BoatOption {
  AddBoat,
  UpdateBoat,
  DeleteBoat,
  Quit,
  None
}
