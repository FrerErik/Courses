package view;

import java.util.Scanner;

import model.domain.Boat;
import model.domain.BoatType;
import model.domain.Member;

import java.io.IOException;
import java.util.ArrayList;

public class p implements MemberBoatUI {

  // Member variables
  private String firstName;
  private String lastName;
  private String personNum;
  private MemberOption chosen;

  // Boat variables
  private String name;
  private BoatType type;
  private double length;

  public void menu() {
    Scanner sc = new Scanner(System.in);
    while (true) {
      String memberMenu;
      System.out.println("Press 1 to create a new member");
      System.out.println("Press 2 to show a list of all members");
      System.out.println("Press 3 to pick a member");
      System.out.println("Press 4 to close the program");
      memberMenu = sc.next();

      if (memberMenu.equals("1")) {
        chosen = MemberOption.AddNewMember;
      } else if (memberMenu.equals("2")) {

      } else if (memberMenu.equals("3")) {

      } else if (memberMenu.equals("4")) {

      }

      if (memberMenu.equals("1")) {
        chosen = MemberOption.AddNewMember;
        System.out.println("Input member's name");
        // Lowercase all letters and then capitalize first letter
        firstName = sc.next();
        System.out.println("Input member's last name");
        lastName = sc.next();
        System.out.println("Input member's personal number'");
        personNum = sc.next();

        while (true) {
          System.out.print("Input boat name: ");
          name = sc.nextLine();
          System.out.println("Select boat type (Sailboat, Motorsailer and KAYAK): ");

          type = BoatType.fromString(sc.nextLine().toLowerCase());
          System.out.println("Boat length: ");
          length = sc.nextDouble();
          System.out.println("Do you want to add another boat? y/n");

          String conditions = sc.next();

          if (conditions.equals("n")) {
            System.out.println("member added");
            chosen = MemberOption.AddNewMember;
            break;

          } else if (conditions.equals("y")) {

          } else {
            System.out.println("invalid Input");
          }

        }

      } else if (memberMenu.equals("2")) {
        String choose;
        System.out.println("Press 1 to display simple list");
        System.out.println("Press 2 to display verbose list");
        choose = sc.next();
        if (choose.equals("1")) {

        } else if (choose.equals("2")) {

        }
        System.out.println("");
        System.out.println("return to menu");
      } else if (memberMenu.equals("3")) {
        System.out.print("to proceed input a member's ID ");
        String member = sc.next();

        if (member.equals("Obama")) {
          System.out.println("name");
          System.out.println("phoneNumber");
          System.out.println("Boats/boatID");

          while (true) {
            System.out.println("Press 1 to change member's name");
            System.out.println("Press 2 to change member's phone number");
            System.out.println("Press 3 to delete current member");
            System.out.println("Press 4 to add a boat");
            System.out.println("Press 5 to delete a boat");
            System.out.println("Press 6 to edit a boat");
            System.out.println("Press 7 to return to previous menu");
            String pick = sc.next();
            String boatID;
            if (pick.equals("1")) {

            } else if (pick.equals("2")) {

            } else if (pick.equals("3")) {

            } else if (pick.equals("4")) {
              System.out.println("Input Boat ID");
              boatID = sc.next();
            } else if (pick.equals("5")) {
              System.out.println("Input Boat ID");
              boatID = sc.next();

            } else if (pick.equals("6")) {
              System.out.println("Input Boat ID");
              boatID = sc.next();

            } else if (pick.equals("7")) {
              System.out.println("returning");
              break;
            }
          }

        } else {
          System.out.println("member not found");
          System.out.println("returning to menu");
        }

      } else if (memberMenu.equals("4")) {
        System.out.println("Thanks for using this program");
        sc.close();
        break;

      }
    }
  }

  public MemberOption getChoosing() {
    return chosen;
  }

  public int getTestID() {
    return 50;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public String getPersonNum() {
    return personNum;
  }

  public String getName() {
    return name;
  }

  public BoatType getType() {
    return type;
  }

  public double getLength() {
    return length;
  }

  @Override
  public int getMemberId() {
    return 50;
  }

  @Override
  public Member showComposeList(Iterable<Member> members) throws IOException {
    return null;
  }

  @Override
  public Member showVerboseList(Iterable<Member> members) throws IOException {
    return null;
  }

  @Override
  public MemberOption getMemberOptions() throws IOException {
    return chosen;
  }

  @Override
  public void onAddNewMember(Iterable<Member> members, Member newMember) {

  }

  @Override
  public void onAddNewBoat(Iterable<Boat> boats, Boat newBoat) {

  }

  @Override
  public void onDeleteMember(Iterable<Member> members, Member deleteMember) {

  }

  @Override
  public void onDeleteBoat(Iterable<Boat> boats, Boat deleteBoat) {

  }

  @Override
  public void onChangeCurrentMember(Member newMember) {

  }

  @Override
  public void onChangeCurrentBoat(Boat newBoat) {

  }

  @Override
  public BoatOption getBoatOptions(Member selected_Member) throws IOException {
    return null;
  }

  @Override
  public ArrayList<Boat> getBoats() {
    // TODO Auto-generated method stub
    return null;
  }

}
