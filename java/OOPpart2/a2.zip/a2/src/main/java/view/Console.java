package view;

import java.util.Scanner;

public class Console {
  private MemberOption choice;
  private ListOption Lchoice;
  private String firstName;
  private String lastName;
  private String personNum;
  private String ID;

  // boat
  private String name;

  private double length;

  public MemberOption DisplayMenu() {
    System.out.println("Press 1 to create a new member");
    System.out.println("Press 2 to show a list of all members");
    System.out.println("Press 3 to pick a member");
    System.out.println("Press 4 to close the program");
    // I feel that what is below belongs in another method.
    String option = GetInput();
    if (option.equals("1")) {
      choice = MemberOption.AddNewMember;
    } else if (option.equals("2")) {
      choice = MemberOption.ShowMemberList;
    } else if (option.equals("3")) {
      choice = MemberOption.PickAMember;
    } else if (option.equals("4")) {
      choice = MemberOption.Quit;
    } else {
      choice = MemberOption.Error;
    }
    return choice;
  }

  public String AddMemberOption() {
    System.out.print("Input member's name: ");
    firstName = String.valueOf(GetInput());
    System.out.print("Input member's last name: ");
    lastName = String.valueOf(GetInput());
    System.out.print("Input member's personal number: ");
    personNum = String.valueOf(GetInput());
    ID = "123";

    String Member = (firstName + ", " + lastName + ", " + personNum + ", " + ID);
    return Member;
  }

  public boolean addBoatConfirmation() {
    // used after creating a Member, or while editing a member and adding a boat
    // from there
    System.out.print("Press y to add a boat other keys will do nothing: ");

    return GetInput() == "y";
  }

  public void addBoat() {
    System.out.print("Input boat name: ");
    name = String.valueOf(GetInput());
    System.out.println("Boat length: ");
    length = Double.valueOf(GetInput());
  }

  public void returnBoatType() {

  }

  public ListOption ShowMemberListChoice() {
    System.out.print("Press 1 to display simple member list");
    System.out.println("Press 2 to display verbose member list");
    String option = GetInput();
    if (option.equals("1")) {
      Lchoice = ListOption.SimpleList;
    } else if (option.equals("2")) {
      Lchoice = ListOption.VerboseList;
    } else {
      Lchoice = ListOption.Error;
    }
    return Lchoice;
  }

  public void DisplayVerboseList() {

  }

  public void DisplaySimpleList() {

  }

  public void PickAMember() {

  }

  public void Quit() {
    System.out.println("Thanks for using this program");
  }

  public void Error() {
    System.out.println("Invalid Input");
  }

  private String GetInput() {
    Scanner scanner = new Scanner(System.in);
    String input = scanner.next();

    return input;
  }
}
