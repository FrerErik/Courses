package view;

public enum MemberMenuOptions {
  ChangeMemberName, CHangeMemberPhone, DeleteMember, AddBoat, DeleteBoat, EditBoat, Quit, Error;
}
