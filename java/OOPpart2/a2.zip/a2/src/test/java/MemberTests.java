
import org.junit.jupiter.api.Test;

import model.domain.Member;

public class MemberTests {

  Member testM = new Member(0, null, null, null, null);

  @Test
  public void addMember() {
    // assertTrue
  }

  public void editMember() {
    // assertTrue
  }

  public void removeMember() {
    // assertTrue
  }

}
