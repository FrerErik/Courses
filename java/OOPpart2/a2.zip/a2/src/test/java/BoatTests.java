import org.junit.jupiter.api.Test;

import model.domain.Boat;

public class BoatTests {

  Boat boatT = new Boat("", 0, null, 0);

  @Test
  public void addBoat() {
    ;
  }

  public void removeBoat() {
    ;
  }

  public void editBoat() {
    ;
  }
}
