# A2

Project for Assignment 2

A project template based on gradle and a gitlab pipeline. You should always build and run the application using gradle regularely.

`./gradlew build`

`./gradlew run -q --console=plain`

Adhere to the git versioning instructions according to the assignment.

Note that this assignment will be automatically checked for plagiarism of source code.