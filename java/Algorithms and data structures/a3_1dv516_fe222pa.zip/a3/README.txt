
In order to run the program its just to run the main method, this time I decided
to put many tests inside a static method so its easier to go through
no tricks to create classes, just create a new class and add the necessary information

if unsure check both main.java and A3Tests.java over there I made my tests clear.

I am reusing my old general time measurer class so to run it will require opencsv, which I implemented with maven and is located in the pomf file
and the class creates a csv file in real time, so it might require admin access to run if it does not work first time.