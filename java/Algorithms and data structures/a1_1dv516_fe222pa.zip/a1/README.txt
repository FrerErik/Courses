## How to run
In order to run the program, run the program "Main.java", in there I present small samples of how the algorithms work and then how I utilize my "general class" to do all the heavy lifting, such as selecting the algorithm, selecting the type of measuring and setting all the necessary parameters.

I utilize a dependency from maven called CSVWriter (Credit to: Scott Conway and Andrew Rucker Jones), so in order to run the program that has to be set up in your device, this project does contain a .pomf file so you just need a maven reader of sorts.


