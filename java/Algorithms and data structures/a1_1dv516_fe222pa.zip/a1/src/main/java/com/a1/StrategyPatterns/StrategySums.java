package com.a1.StrategyPatterns;

import java.util.List;

public interface StrategySums {
  public void StrategySetSize(int size, int rangeOfSet);

  public List<String[]> StrategySumAlgorithm();
}
