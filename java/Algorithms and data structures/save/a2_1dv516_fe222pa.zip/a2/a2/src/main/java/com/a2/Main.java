package com.a2;

import java.io.IOException;
import java.util.Iterator;

import com.a2.BinarySearchTree.BTNode;
import com.a2.BinarySearchTree.BinarySearchTree;
import com.a2.LinkedLists.SingleLinkedListReverse;
import com.a2.P4DirectoryFinder.P4DirectoryDisplay;
import com.a2.RandomizedQueue.RandomizedQueue;
import com.a2.doubleEndedQueue.GenericDeque;

public class Main {
  public static void main(String[] args) throws CloneNotSupportedException, IOException {
    /* P1 Reverse linked list demonstration */
    System.out.println("SLLR Demonstration: \n");
    SingleLinkedListReverse sllr = new SingleLinkedListReverse();

    System.out.println("Empty?: " + sllr.isEmpty());
    System.out.println("adding variables");
    sllr.append(1);
    sllr.append(2);
    sllr.append(3);
    sllr.append(4);
    sllr.append(6);
    System.out.println("Empty?: " + sllr.isEmpty());
    System.out.println("Size: " + sllr.size());
    System.out.println(sllr.fullList());
    System.out.println("-------------------------------------------- \n");
    /* P2 generic deque demonstration */

    System.out.println("GD demonstration: add and removing front\n");

    GenericDeque<Integer> gD = new GenericDeque<Integer>();
    System.out.println("test if errors deleting empty lists show up:");
    gD.removeFront();
    gD.removeRear();
    for (int i = 1; i <= 10; i++) {
      gD.addFront(i);
    }

    Iterator<Integer> iterator = gD.iterateFrontToBack();
    while (iterator.hasNext()) {
      System.out.print(iterator.next() + "|");
    }

    System.out.println("\nAdding back and front --------------------------------------");

    gD.addRear(100);
    gD.addRear(110);
    gD.addFront(120);
    gD.addFront(130);

    iterator = gD.iterateFrontToBack();
    while (iterator.hasNext()) {
      System.out.print(iterator.next() + "|");
    }

    System.out.println("\nremoving back and front--------------------------------------");

    gD.removeFront();
    gD.removeFront();
    gD.removeRear();
    gD.removeRear();

    iterator = gD.iterateFrontToBack();
    while (iterator.hasNext()) {
      System.out.print(iterator.next() + "|");
    }
    System.out.println("\nRemovingTests--------------------");
    while (!gD.isEmpty()) {
      gD.removeRear();
    }

    System.out.println("\nEmpty? " + gD.isEmpty());
    System.out.println("\n\nGD demonstration add last and removing last");

    System.out.println("--------------------------------");
    System.out.println("Randomized Queue RQ demonstration: \n");

    RandomizedQueue<Integer> rQ = new RandomizedQueue<Integer>();

    for (int i = 0; i <= 10; i++) {
      rQ.enqueue(i);
    }
    Iterator<Integer> itRQ = rQ.iterateFrontToBack();
    while (itRQ.hasNext()) {
      int i = itRQ.next();
      System.out.print(i + "| ");
    }

    System.out.println("\ndelete: " + rQ.dequeue());

    itRQ = rQ.iterateFrontToBack();
    while (itRQ.hasNext()) {
      int i = itRQ.next();
      System.out.print(i + "| ");
    }

    System.out.println("\n--------------------------------");
    System.out.println("RandomIterator Demonstration:");
    itRQ = rQ.RandomIterator();
    while (itRQ.hasNext()) {
      int i = itRQ.next();
      System.out.print(i + "| ");
    }

    System.out.println("\n--------------------------------");
    System.out.println("dequeuing until empty test: \n");
    while (!rQ.isEmpty()) {
      System.out.println("\nremoved: " + rQ.dequeue());
      itRQ = rQ.iterateFrontToBack();
      while (itRQ.hasNext()) {
        int i = itRQ.next();
        System.out.print(i + "| ");
      }
    }
    System.out.println("Empty?: " + rQ.isEmpty());

    System.out.println("--------------------------------");
    System.out.println("DirectoryDisplay DD demonstration: \n");

    P4DirectoryDisplay DD = new P4DirectoryDisplay(new java.io.File(".").getCanonicalPath() + "/P4DTests");

    DD.walk();
    System.out.println("Testing left right paths --------------------------------\n");
    System.out.println(DD.getRoot().getNChild(0).getNChild(1).getNChild(0).getNChild(0).key);
    // should say --H
    System.out.println(DD.getRoot().getNChild(0).getNChild(1).getNChild(0).getNChild(1).key);
    // should say -E
    System.out.println(
        DD.getRoot().getNChild(0).getNChild(1).getNChild(0).getNChild(1).getNChild(0).getNChild(0).getNChild(0)
            .getNChild(0).key);

    System.out.println(
        DD.getRoot().getNChild(0).getNChild(1).getNChild(0).getNChild(1).getNChild(0).getNChild(0).key);
    // gives J, if next is 0 should give P if its 1 instead, it should give Test
    System.out.println(
        DD.getRoot().getNChild(0).getNChild(1).getNChild(0).getNChild(1).getNChild(0).getNChild(0).getNChild(0).key);
    System.out.println(
        DD.getRoot().getNChild(0).getNChild(1).getNChild(0).getNChild(1).getNChild(0).getNChild(0).getNChild(1).key);

    // recap, Use image "aim.png" for reference, if the values are [--H, -E, ---Q,
    // --J, ---P and --Test] then all is working as intended.

    System.out.println("--------------------------------");
    System.out.println("BinarySearchTree BST demonstration: \n");

    BinarySearchTree bst = new BinarySearchTree();
    bst.add(4);
    bst.add(3);
    bst.add(2);
    bst.add(6);
    bst.add(5);
    bst.add(9);
    bst.add(7);
    bst.add(11);

    System.out.println(bst.root.right.key);
    bst.remove(6);
    System.out.println(bst.root.right.key);// success

    System.out.println("Size: " + bst.size(bst.root));
    System.out.println("\niterator Tests: --------------------------------------");
    bst.resetRoot();
    bst.add(4);
    bst.add(2);
    bst.add(5);
    bst.add(1);
    bst.add(3);
    bst.add(6);

    Iterator<BTNode> it = bst.inorderIterator();
    System.out.print("in order iter [");
    while (it.hasNext()) {
      System.out.print(it.next().key + ",");
    }
    System.out.print("]\n");

    it = bst.postIterator();
    System.out.print("post order iter [");
    while (it.hasNext()) {
      System.out.print(it.next().key + ",");
    }
    System.out.print("]\n");

    it = bst.preIterator();
    System.out.print("pre order iter [");
    while (it.hasNext()) {
      System.out.print(it.next().key + ",");
    }
    System.out.print("]\n");

    bst.resetRoot();
    System.out.println("(resetNode)KthValueTest---------------------");
    for (int i = 1; i <= 10; i++) {
      bst.add(i);

    }

    bst.removeKthLargest(3);
    System.out.println(bst.max(bst.root));
    System.out.println(bst.contains(bst.root, 8));// great success
    System.out.println("IfKisInvalid--------------------------------");
    bst.removeKthLargest(11);
    bst.removeKthLargest(0);

  }

}
