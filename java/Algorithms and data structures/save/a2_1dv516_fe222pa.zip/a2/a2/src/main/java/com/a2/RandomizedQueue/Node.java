package com.a2.RandomizedQueue;

public class Node<obj> {

  public obj obj;
  public Node<obj> next;

  public Node(obj obj) {
    this.obj = obj;
  }
}
