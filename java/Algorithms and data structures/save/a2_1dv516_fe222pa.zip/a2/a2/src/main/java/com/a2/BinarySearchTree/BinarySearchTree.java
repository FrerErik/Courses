package com.a2.BinarySearchTree;

import java.util.Iterator;

import com.a2.doubleEndedQueue.GenericDeque;

public class BinarySearchTree {

  public BTNode root;
  int maxHeight;

  public void resetRoot() {
    this.root = null;
  }

  public BinarySearchTree() {
    this(null);
  }

  public BinarySearchTree(BTNode root) {
    this.root = root;
  }

  public int height(BTNode node) {
    if (node == null) {
      return -1;
    }
    return 1 + maxVal(height(node.left), height(node.right));
  }

  public int size(BTNode root) {
    if (root == null) {
      return 0;
    } else {
      return size(root.left) + 1 + size(root.right);
    }
  }

  private BTNode add(BTNode node, int key) {
    if (node == null) {
      return new BTNode(key);
    }
    if (node.key > key) {
      node.left = add(node.left, key);
    } else if (node.key < key) {
      node.right = add(node.right, key);
    }
    return node;
  }

  public void add(int key) {
    this.root = add(this.root, key);
  }

  private BTNode delete(BTNode node, int key) {
    if (node == null) {
      return null;
    }
    if (node.key > key) {
      node.left = delete(node.left, key);
    } else if (node.key < key) {
      node.right = delete(node.right, key);
    } else {
      if (node.right == null) {
        return node.left;
      }
      if (node.left == null) {
        return node.right;
      }
      node.key = min(node.right);
      node.right = delete(node.right, node.key);
    }
    return node;
  }

  public int min(BTNode node) {
    if (node.left == null) {
      return node.key;
    } else {
      return min(node.left);
    }
  }

  public int max(BTNode node) {
    if (node.right == null) {
      return node.key;
    } else {
      return max(node.right);
    }
  }

  public void removeKthLargest(int kth) {
    int value = getKthLargest(this.root, kth);
    if (value < 0) {
      return;
    }
    this.root = delete(this.root, value);
  }

  public int maxVal(int a, int b) {
    if (a < b) {
      return b;
    } else if (a == b) {
      return a;
    }
    return a;
  }

  /* Works */
  public int getKthLargest(BTNode b, int k) {
    k = k - 1;
    if (k < 0 || (k > size(b))) {
      System.out.println("Error no such value");
      return -1;
    }
    BTNode temp = copyBSTree(b);
    int value = temp.key;

    for (int i = 0; i < k; i++) {
      int val = max(temp);
      temp = delete(temp, val);
    }
    if (temp == null) {
      return value;
    }
    value = max(temp);
    temp = null;

    return value;
  }

  /*
   * Idea is to recursively create a copy of the original tree with different
   * pointers so the original is kept intact
   */
  public BTNode copyBSTree(BTNode root) {
    if (root == null) {
      return null;
    }
    BTNode copy = new BTNode(root.key);
    copy.left = copyBSTree(root.left);
    copy.right = copyBSTree(root.right);

    return copy;
  }

  public int getLargest(BTNode b) {
    if (b.right == null) {
      return b.key;
    } else {
      return getLargest(b.right);
    }
  }

  public void remove(int key) {
    this.root = delete(this.root, key);
  }

  public boolean contains(BTNode node, int key) {
    if (node == null) {
      return false;
    }
    int val = node.key - key;

    if (val > 0) {
      return contains(node.left, key);
    } else if (val < 0) {
      return contains(node.right, key);
    } else {
      return true;
    }

  }

  public Iterator<BTNode> postIterator() {
    return new postIterator();
  }

  public Iterator<BTNode> preIterator() {
    return new preIterator();
  }

  public Iterator<BTNode> inorderIterator() {
    return new inorderIterator();
  }

  /*
   * pre: root, root.left, root.left.left, root.left.right, root.left.left.left
   * ... then root.right root.right.left root.right.right root.right.right.left
   * ...
   */

  private class preIterator implements Iterator<BTNode> { // TODO

    GenericDeque<BTNode> stackDeque;

    public preIterator() {
      stackDeque = new GenericDeque<BTNode>();
      stackDeque.addFront(root);
    }

    public void recur(BTNode node) {
      stackDeque.addFront(node);
    }

    @Override
    public boolean hasNext() {
      return !stackDeque.isEmpty();
    }

    @Override
    public BTNode next() {
      BTNode temp = stackDeque.removeFront();
      if (temp.right != null) {
        recur(temp.right);
      }
      if (temp.left != null) {
        recur(temp.left);
      }
      return temp;
    }

  }
  /*
   * post: bottom left.left, bottom left.right, parent, bottom right.left, bottom
   * right.right, parent till root
   */

  private class postIterator implements Iterator<BTNode> {

    GenericDeque<BTNode> stackDeque;

    public postIterator() {
      stackDeque = new GenericDeque<BTNode>();
      recursive(root);
    }

    public void recursive(BTNode node) {
      while (node != null) {
        stackDeque.addFront(node); // adds root, root.left, root.left.left ...
        if (node.left != null) {
          node = node.left;
        } else {
          node = node.right;
        }
      }

    }

    @Override
    public boolean hasNext() {
      return !stackDeque.isEmpty();
    }

    @Override
    public BTNode next() {
      if (!stackDeque.isEmpty()) {
        BTNode tmp = stackDeque.removeFront();
        if (!stackDeque.isEmpty()) {
          if (tmp == stackDeque.checkTop().left) { // since provide
            recursive(stackDeque.checkTop().right);
          }
        }
        return tmp;
      }
      System.out.println("error");
      return null;
    }

  }
  /*
   * In order : take away is that it takes the smallest value until it cannot find
   * more.
   */

  private class inorderIterator implements Iterator<BTNode> {
    GenericDeque<BTNode> stackDeque;

    public inorderIterator() {
      stackDeque = new GenericDeque<BTNode>();
      recursiveMin(root);
    }

    public void recursiveMin(BTNode node) {
      while (node != null) {
        stackDeque.addFront(node); // adds root, root.left, root.left.left ...
        node = node.left;
      }
    }

    @Override
    public boolean hasNext() {
      return !stackDeque.isEmpty();
    }

    @Override
    public BTNode next() {
      if (!stackDeque.isEmpty()) {
        BTNode tmp = stackDeque.removeFront();
        if (tmp.right != null) {
          recursiveMin(tmp.right);
        }
        return tmp;
      }
      System.out.println("error");
      return null;
    }

  }

}
