package com.a2.LinkedLists;

public class Node {

  public Node(int value) {
    this.value = value;
  }

  public int value;
  public Node prev;
}
