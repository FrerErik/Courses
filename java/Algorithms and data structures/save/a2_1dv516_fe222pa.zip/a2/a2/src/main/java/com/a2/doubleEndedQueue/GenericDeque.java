package com.a2.doubleEndedQueue;

import java.util.Iterator;

public class GenericDeque<obj> {
  int count;
  public Node<obj> front;
  public Node<obj> rear;

  public GenericDeque() {
    this.front = null;
    this.rear = null;
    this.count = 0;
  }

  public int size() {
    return this.count;
  }

  public boolean isEmpty() {
    return this.count == 0;
  }

  public obj checkTop() {
    return this.front.obj;
  }

  public obj checkBottom() {
    return this.rear.obj;
  }

  public void addRear(obj value) {
    Node<obj> temp = new Node<obj>(value);

    if (this.rear == null) {
      this.rear = temp;
      this.front = temp;
      this.count++;
    } else {
      temp.prev = rear;
      this.rear.next = temp;
      this.rear = temp;
      this.count++;
    }

  }

  public void addFront(obj value) {
    Node<obj> temp = new Node<obj>(value);

    if (this.front == null) {
      rear = temp;
      front = temp;
    } else {
      temp.next = front;
      front.prev = temp;
      front = temp;
    }
    this.count++;
  }

  public obj removeFront() {
    if (isEmpty()) {
      System.out.println("Error trying to delete empty list");
      return null;
    } else {
      obj temp = this.front.obj;
      this.front = this.front.next;
      this.count -= 1;

      if (this.front == null) {
        rear = null;
        return temp;
      } else {
        front.prev = null;
        return temp;
      }
    }
  }

  public obj removeRear() {
    if (this.rear == null) {
      System.out.println("Error trying to delete empty list");
      return null;
    } else {
      obj temp = this.rear.obj;
      this.rear = this.rear.prev;
      this.count -= 1;
      if (this.rear == null) {
        front = null;
        return temp;
      } else {
        rear.next = null;
        return temp;
      }
    }
  }

  public Iterator<obj> iterateFrontToBack() {

    return new DQIterator();
  }

  private class DQIterator implements Iterator<obj> {

    private Node<obj> position = front;

    @Override
    public boolean hasNext() {
      return (position != null);
    }

    @Override
    public obj next() {
      obj val = position.obj;
      position = position.next;
      return val;
    }

  }

}
