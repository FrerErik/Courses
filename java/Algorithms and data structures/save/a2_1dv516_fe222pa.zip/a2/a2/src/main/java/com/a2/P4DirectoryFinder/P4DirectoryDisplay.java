package com.a2.P4DirectoryFinder;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import com.a2.doubleEndedQueue.GenericDeque;

public class P4DirectoryDisplay {
  // all works, just gotta do so test and test2 show up.
  Node<String> root;

  public Node<String> getRoot() {
    return this.root;
  }

  File directory;

  public void walk() throws IOException {
    root.walk();
  }

  public Iterator<File> pathsInDir(File directory) {
    GenericDeque<File> allPathsInADir = new GenericDeque<File>();
    for (File f : directory.listFiles()) {
      allPathsInADir.addRear(f);
    }
    return allPathsInADir.iterateFrontToBack();
  }

  public boolean isLeafDir(File f) {
    if (f.isDirectory()) {
      int dirLength = f.list().length;
      if (dirLength > 0) {
        return false;
      }
    }
    return true;
  }

  public P4DirectoryDisplay(String path) throws IOException { // add Child adds left first
    String initialDirectory = path;
    directory = new File(initialDirectory);
    root = new Node<String>(directory.getName());
    Node<String> node = null;
    boolean firstTime = true;
    for (File f : directory.listFiles()) {
      String depth = "-";
      String depthRep = depth;
      if (firstTime) {
        node = root.addChild(depthRep + f.getName());
        firstTime = false;

      } else {

        Node<String> pNode = node;
        node = null;
        node = pNode.addChild(depthRep + f.getName());
      }
      Node<String> storeNode = node;
      File temp = f;
      depthRep = depthRep + depth;
      boolean done = true;
      String dynamicDepth = "";
      GenericDeque<Iterator<File>> iteratorStates = new GenericDeque<Iterator<File>>();
      boolean itState = false;
      Node<String> nodeState = null;
      while (!isLeafDir(temp)) {

        Iterator<File> paths = pathsInDir(temp);
        if (itState) {
          paths = iteratorStates.removeFront();
          itState = false;
        }
        while (paths.hasNext()) {
          File l = paths.next();
          Node<String> currNode = node;
          node = null;
          node = currNode.addChild(depthRep + l.getName());
          if (!isLeafDir(l)) {

            if (paths.hasNext()) {
              iteratorStates.addRear(paths);
              dynamicDepth = depthRep;
              nodeState = node;
            }
            temp = l;
            done = false;
            depthRep = depthRep + depth;
            break;
          }
          done = true;
        }
        if (done) {
          if (iteratorStates.isEmpty()) {
            break;
          } else {
            depthRep = dynamicDepth;
            itState = true;
            node = nodeState;
          }

        }
      }
      node = storeNode;
    }

  }
}
