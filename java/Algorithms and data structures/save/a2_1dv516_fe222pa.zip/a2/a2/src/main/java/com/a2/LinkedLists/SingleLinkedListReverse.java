package com.a2.LinkedLists;

/* This linked list is meat to go reverse 
 * in short we want this:
 * add(1), add(2) ... add(5)
 * print ls = 5, 4, 3, 2, 1
 * 1, prev = null
 * 2, prev = (1, prev = null)
*  3, prev = (2, prev = (1, prev = null))
*/
public class SingleLinkedListReverse {
  private Node nodes;

  public void append(int d) {
    if (this.nodes == null) {
      this.nodes = new Node(d);
      this.nodes.prev = null;
    } else {
      // System.out.println("Previous node value: " + this.nodes.value);
      Node p = new Node(d);
      p.prev = this.nodes;
      this.nodes = p;
      // System.out.println("Current node value: " + p.value);
    }

  }

  public boolean isEmpty() {
    return this.nodes == null;
  }

  public int size() {
    int count = 0;
    Node test = this.nodes;
    while (test != null) {
      test = test.prev;
      count += 1;
    }
    return count;
  }

  public String fullList() {
    Node test = this.nodes;
    String s = "";
    while (test != null) {
      s += String.valueOf(test.value);
      s += "|";
      test = test.prev;
    }
    return s;
  }

}
