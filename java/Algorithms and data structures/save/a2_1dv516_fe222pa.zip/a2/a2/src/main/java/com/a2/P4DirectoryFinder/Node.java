package com.a2.P4DirectoryFinder;

public class Node<obj> {
  public obj key;
  public Node<obj> left;
  public Node<obj> right;

  public Node(obj key) {
    this.key = key;
    this.left = null;
    this.right = null;
  }

  public void walk() {
    System.out.println(this.key);
    if (this.left != null) {
      this.left.walk();
    }
    if (this.right != null) {
      this.right.walk();
    }
  }

  public Node<obj> addChild(obj key) {
    if (this.left == null) {
      this.left = new Node<obj>(key);
      return this.left;
    } else {
      Node<obj> p = this.left;
      while (p.right != null) {
        p = p.right;
      }
      p.right = new Node<obj>(key);
      return p.right;
    }
  }

  public int degree() {
    int s = 0;
    Node<obj> p = this.left;
    while (p != null) {
      s++;
      p = p.right;
    }
    return s;
  }

  public boolean isLeaf() {
    return this.left == null;
  }

  public Node<obj> getNChild(int key) {
    int c = 0;
    Node<obj> p = this.left;
    while (p != null) {
      if (c == key) {
        return p;
      }
      c++;
      p = p.right;
    }
    return null;
  }

  public int size() {
    int l = 0;
    int r = 0;
    if (this.left != null) {
      l = this.left.size();
    }
    if (this.right != null) {
      r = this.right.size();
    }
    return 1 + l + r;
  }

  public int height() {
    int h = 0;
    Node<obj> p = this.left;
    while (p != null) {
      h = Math.max(h, 1 + p.height());
      p = p.right;
    }
    return h;
  }
}
