package com.a2.BinarySearchTree;

public class BTNode {
  public int key;
  public BTNode left;
  public BTNode right;

  public BTNode(int key) {
    this(key, null, null);
  }

  public BTNode(int key, BTNode left, BTNode right) {
    this.key = key;
    this.left = left;
    this.right = right;
  }
}
