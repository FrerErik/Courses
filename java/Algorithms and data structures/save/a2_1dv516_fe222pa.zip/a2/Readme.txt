I presented all implementation tests in the Main program
every single implementation is inside its own corresponding folder 
I do not reuse them except for deque, its just an amazing way of going through the data

no many notes on how to run, just create a class and test.

regarding 4 It is the only one that has a constructor that requires something,
that is stated in the instructions.
also the folder contains a picture, I based most of my tests on it, I added some other folders
that are no shown there, easiest way to test is to just open with debug and check where things point to

running Main also presents my tests and examples on how to run them if its not clear.

Note: if example for 4 provides an error the String for the file looks this way:
C:\Users\me\Desktop\...\a2\P4DTests

