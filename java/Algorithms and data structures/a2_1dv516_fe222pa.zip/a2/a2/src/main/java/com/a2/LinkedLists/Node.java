package com.a2.LinkedLists;

public class Node {
  public int valueInside;
  public Node next;

  public void setValue(int valueInside) {
    this.valueInside = valueInside;
  }

  public Node(int valueInside) {
    this.valueInside = valueInside;
  }

}
