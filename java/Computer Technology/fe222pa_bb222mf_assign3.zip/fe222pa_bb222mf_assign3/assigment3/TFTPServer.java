package assigment3;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;

public class TFTPServer {
  public static final int TFTPPORT = 4730;
  public static final int BUFSIZE = 516;
  public static final String READDIR = "C:/Program Files/Tftpd64/Tests/Read"; // f, "C:/Program
  // Files/Tftpd64/Tests/Read",
  public static final String WRITEDIR = "C:/Program Files/Tftpd64/Tests/Write"; // f "C:/Program
                                                                                // Files/Tftpd64/Tests/Write",
  // OP codes
  public static final int OP_RRQ = 1;
  public static final int OP_WRQ = 2;
  public static final int OP_DAT = 3;
  public static final int OP_ACK = 4;
  public static final int OP_ERR = 5;
  public static final int OP_DATA = 1;

  public static void main(String[] args) {
    if (args.length > 0) {
      System.err.printf("usage: java %s\n", TFTPServer.class.getCanonicalName());
      System.exit(1);

    }
    // Starting the server
    try {
      TFTPServer server = new TFTPServer();
      server.start();
    } catch (SocketException e) {
      e.printStackTrace();
    }
  }

  private void start() throws SocketException {
    byte[] buf = new byte[BUFSIZE];

    // Create socket
    DatagramSocket socket = new DatagramSocket(null);

    // Create local bind point
    SocketAddress localBindPoint = new InetSocketAddress(TFTPPORT);
    socket.bind(localBindPoint);
    System.out.printf("Listening at port %d for new requests\n", TFTPPORT);

    // Loop to handle client requests
    while (true) {

      final InetSocketAddress clientAddress = receiveFrom(socket, buf);

      // If clientAddress is null, an error occurred in receiveFrom()
      if (clientAddress == null)
        continue;

      final StringBuffer requestedFile = new StringBuffer();
      final int reqtype = ParseRQ(buf, requestedFile);

      new Thread() {
        public void run() {
          try {
            DatagramSocket sendSocket = new DatagramSocket(0);

            // Connect to client
            sendSocket.connect(clientAddress);
            // gives errors for
            System.out.printf("%s request for %s from %s using port %d\n",
                (reqtype == OP_RRQ) ? "Read" : "Write",
                clientAddress.getHostName(), clientAddress.getAddress(), clientAddress.getPort());

            // Read request
            if (reqtype == OP_RRQ) {
              requestedFile.insert(0, READDIR);

              HandleRQ(sendSocket, requestedFile.toString(), OP_RRQ);
            }
            // Write request
            else {
              requestedFile.insert(0, WRITEDIR);
              // System.out.println(requestedFile.toString());
              HandleRQ(sendSocket, requestedFile.toString(), OP_WRQ);
            }
            sendSocket.close();
          } catch (SocketException e) {
            e.printStackTrace();
          } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
          }
        }
      }.start();
    }
  }

  /**
   * Reads the first block of data, i.e., the request for an action (read or
   * write).
   * 
   * @param socket (socket to read from)
   * @param buf    (where to store the read data)
   * @return socketAddress (the socket address of the client)
   */
  private InetSocketAddress receiveFrom(DatagramSocket socket, byte[] buf) {

    // Create datagram packet,

    DatagramPacket packet = new DatagramPacket(buf, 0, buf.length);

    // Receive packet
    try {
      socket.receive(packet);
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    // Get client address and port from the packet
    InetSocketAddress socketAddress = new InetSocketAddress(packet.getAddress(), packet.getPort());

    return socketAddress;
  }

  /**
   * Parses the request in buf to retrieve the type of request and requestedFile
   * 
   * @param buf           (received request)
   * @param requestedFile (name of file to read/write)
   * @return opcode (request type: RRQ or WRQ)
   *         RRQ = 1, WRQ = 2.
   */
  private int ParseRQ(byte[] buf, StringBuffer requestedFile) {
    // See "TFTP Formats" in TFTP specification for the RRQ/WRQ request contents
    ByteBuffer wrap = ByteBuffer.wrap(buf);
    short opcode = wrap.getShort();
    String test = "";
    ByteArrayOutputStream out = new ByteArrayOutputStream();

    boolean fileNotCompleted = true;

    while (wrap.remaining() > 0) {

      byte a = wrap.get();
      if (a == 0) {
        fileNotCompleted = false;
      }
      if (a != 0) {
        if (fileNotCompleted) {
          out.write(a);
        }

      }
    }
    test = out.toString(StandardCharsets.UTF_8);

    System.out.println("Request type: " + opcode);
    requestedFile.append("/" + test);

    return opcode;
  }

  /**
   * To be implemented
   * 
   * @param requestedFile
   */
  private boolean send_DATA_receive_ACK(DatagramSocket sendSocket, String requestedFile) {
    // important values
    byte dataBlock = OP_DATA;
    byte dataBlockLeftSide = 0;
    short opcode = 0;
    short block = 0;
    boolean timeoutCancel = false;
    boolean wrongPacket = false;
    int differenceForChecksum = 0;
    // getting File byte size
    File file = new File(requestedFile.toString());
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    byte[] totalFileData;
    try {
      totalFileData = Files.readAllBytes(file.toPath());
      byte[] maxiumLast = new byte[BUFSIZE - 5]; // last block should be 511 bytes
      byte[] maximum = new byte[BUFSIZE - 4];

      // calculating how many loops are required

      ByteBuffer wrapTotal = ByteBuffer.wrap(totalFileData);
      int checkRound = 1;
      List<byte[]> totalFile = new ArrayList<byte[]>();
      // System.out.println(totalFileData.length);

      for (int i = 0; i < totalFileData.length; i++) {
        byte a = wrapTotal.get();
        out.write(a);
        if ((i + 1) == (int) totalFileData.length) {
          byte[] b = out.toByteArray();
          totalFile.add(b);
        }
        if (i + 1 == 512 * checkRound) {
          byte[] b = out.toByteArray();
          totalFile.add(b);
          checkRound += 1;
          out.reset();
        }
      }
      // System.out.println(checkRound);

      // part 1 send;
      for (int i = 0; i < checkRound; i++) {

        if (i + 1 == checkRound) {
          maximum = maxiumLast;
        }

        byte[] fileData = totalFile.get(i);
        // System.out.println("fileData: " + fileData.length + " maxLength: " +
        // maximum.length);

        byte[] sendDataMagicBytes = { 0, 3, dataBlockLeftSide, dataBlock };

        byte[] finalD = Arrays.copyOf(sendDataMagicBytes, sendDataMagicBytes.length + fileData.length);
        System.arraycopy(fileData, 0, finalD, sendDataMagicBytes.length, fileData.length);

        // means to know what type of data I am sending
        // ByteBuffer wrap = ByteBuffer.wrap(finalD);
        // System.out.println(wrap.getShort() + " and " + wrap.getShort());

        DatagramPacket sendPacket = new DatagramPacket(finalD, finalD.length);

        int checkSum = Byte.toUnsignedInt(dataBlock) + Byte.toUnsignedInt(dataBlockLeftSide) * 255;
        checkSum += differenceForChecksum;
        sendSocket.send(sendPacket);
        if (dataBlock == (byte) 255) {
          dataBlock = (byte) 0;
          dataBlockLeftSide = (byte) (dataBlockLeftSide + 1);
          differenceForChecksum += 1;
        } else {
          dataBlock = (byte) (dataBlock + 1);
        }

        byte[] ACK = new byte[BUFSIZE];
        try {
          sendSocket.setSoTimeout(5000); // this looks for timeouts
          // part 2 acknowledge needs timeout function;

          DatagramPacket acknowledgePacket = new DatagramPacket(ACK, 0, ACK.length);
          sendSocket.receive(acknowledgePacket);

          ByteBuffer wrap = ByteBuffer.wrap(ACK);
          opcode = wrap.getShort();
          block = wrap.getShort();
          // System.out.println(opcode + " " + block);

          int blockInt = (int) block;

          // System.out.println(checkSum + " " + blockInt);

          if (opcode == 4 && blockInt == checkSum) {
            wrongPacket = false;
          } else {
            if (wrongPacket) {
              send_ERR(sendSocket, requestedFile, 0);
              System.out.println("Incorrect packet sent");
              break;
            }
            i = i - 1;
            wrongPacket = true;
          }

          // check type of packet
          // System.out.println(opcode + " " + block);
          timeoutCancel = false;

        } catch (SocketTimeoutException e) {

          if (timeoutCancel) {
            e.printStackTrace();
            send_ERR(sendSocket, requestedFile, 0);
            break;
          }
          i = i - 1;
          timeoutCancel = true;
        }
      }
    } catch (IOException e1) { // file not found
      file.delete();
      send_ERR(sendSocket, requestedFile, 1);
    }

    // System.out.println(opcode + " " + block);
    if (opcode == 4) {
      return true;
    } else {
      file.delete();
      return false;
    }

  }

  private synchronized byte[] serverData(DatagramSocket sendSocket) {
    byte[] tempData = new byte[BUFSIZE];
    byte[] serverData;
    DatagramPacket getPacket = new DatagramPacket(tempData, tempData.length);
    try {
      sendSocket.receive(getPacket);
      serverData = new byte[getPacket.getLength()];
      System.arraycopy(tempData, 0, serverData, 0, getPacket.getLength());
      return serverData;
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return null;
  }

  private boolean receive_DATA_send_ACK(DatagramSocket sendSocket, String requestedFile) {

    short opcode = 5;
    boolean receivePackets = true;

    List<byte[]> onlyData = new ArrayList<byte[]>();
    try {
      File file = new File(requestedFile);

      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte AcknowledgeLeftSide = 0;
      byte AcknowledgeRightSide = 0;
      if (file.createNewFile()) {
        FileOutputStream FOS = new FileOutputStream(file);
        while (true) {

          byte[] data = new byte[BUFSIZE];

          byte[] ACK = { 0, 4, AcknowledgeLeftSide, AcknowledgeRightSide };
          DatagramPacket sendacknowledgement = new DatagramPacket(ACK, ACK.length);
          sendSocket.send(sendacknowledgement);
          // System.out.println(AcknowledgeLeftSide + " aaa" + AcknowledgeRightSide);

          if (receivePackets) {
            data = serverData(sendSocket);
            if (data.length != 516) {
              receivePackets = false;
            }
          } else {
            break;
          }

          if (AcknowledgeRightSide == (byte) 255) {

            AcknowledgeRightSide = 0;
            AcknowledgeLeftSide = (byte) (AcknowledgeLeftSide + 1);
          } else {
            AcknowledgeRightSide = (byte) (AcknowledgeRightSide + 1);
          }

          int dataSize = data.length;
          // System.out.println(dataSize);

          ByteBuffer wrap = ByteBuffer.wrap(data);

          opcode = wrap.getShort();
          short block = wrap.getShort();
          ;

          while (wrap.remaining() > 0) {
            byte a = wrap.get();
            out.write(a);
          }
          onlyData.add(out.toByteArray());
          out.reset();

        }

        for (int i = 0; i < onlyData.size(); i++) {
          FOS.write(onlyData.get(i));
        }
        FOS.close();

      } else { // file already exists error

        send_ERR(sendSocket, requestedFile, 6);
      }

    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      send_ERR(sendSocket, requestedFile, 0);
    } catch (Exception e) {
      e.printStackTrace();
      send_ERR(sendSocket, requestedFile, 0);
    }
    if (opcode == 3) {
      return true;
    } else {
      return false;
    }

  }

  // works for 0 and 6, others it bugs
  private void send_ERR(DatagramSocket sendSocket, String requestedFile, int typeOfError) {
    String errorMsg = "";
    byte[] errorCode = { 0, 5, 0, (byte) typeOfError };
    Charset charset = Charset.forName("US-ASCII");
    CharsetEncoder cEncoder = charset.newEncoder();
    CharsetDecoder cDecoder = charset.newDecoder();
    if (typeOfError == 0) {
      errorMsg = "Not defined, see error message (if any)";
    } else if (typeOfError == 1) {
      errorMsg = "File not found";
    } else if (typeOfError == 2) {
      errorMsg = "Access violation";
    } else if (typeOfError == 6) {
      errorMsg = "File already exists";
    }

    try {
      ByteBuffer wrap = cEncoder.encode(CharBuffer.wrap(errorMsg));
      CharBuffer cBuffer = cDecoder.decode(wrap);
      errorMsg = cBuffer.toString();
    } catch (Exception e) {
      e.printStackTrace();
    }
    System.out.println(errorMsg);

    byte[] errorMsgBytes = errorMsg.getBytes();
    for (int i = 0; i < errorMsgBytes.length; i++) {
      // System.out.println(errorMsgBytes[i]);
    }

    System.out.println("--------------");

    byte[] finalErrorMsg = Arrays.copyOf(errorCode, errorCode.length + errorMsgBytes.length);
    System.arraycopy(errorMsgBytes, 0, finalErrorMsg, errorCode.length, errorMsgBytes.length);

    ByteBuffer wrap = ByteBuffer.wrap(finalErrorMsg);
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    ByteArrayOutputStream test = new ByteArrayOutputStream();

    while (wrap.remaining() > 0) {

      byte a = wrap.get();
      out.write(a);
    }
    out.write(0);

    // System.out.println(out.toString());

    finalErrorMsg = out.toByteArray();

    for (int i = 0; i < finalErrorMsg.length; i++) {
      // System.out.println(finalErrorMsg[i]);
      test.write(finalErrorMsg[i]);
      // System.out.println(test.toString());
      test.reset();
    }

    DatagramPacket errorPacket = new DatagramPacket(finalErrorMsg, finalErrorMsg.length);

    try {
      sendSocket.send(errorPacket);
    } catch (IOException e) {
      // send_ERR(sendSocket, requestedFile, 0);
      e.printStackTrace();
    }
  }

  /**
   * Handles RRQ and WRQ requests
   * 
   * @param sendSocket    (socket used to send/receive packets)
   * @param requestedFile (name of file to read/write)
   * @param opcode        (RRQ or WRQ)
   * @throws IOException
   */
  private void HandleRQ(DatagramSocket sendSocket, String requestedFile, int opcode) {

    if (opcode == OP_RRQ) {
      // See "TFTP Formats" in TFTP specification for the DATA and ACK packet contents
      boolean result = send_DATA_receive_ACK(sendSocket, requestedFile);
      if (!result) {
        System.out.println("Error acknowledging");
      }
    } else if (opcode == OP_WRQ) {
      boolean result = receive_DATA_send_ACK(sendSocket, requestedFile);
      if (!result) {
        System.out.println("Error acknowledging");
      }
    } else {
      System.err.println("Invalid request. Sending an error packet.");
      // See "TFTP Formats" in TFTP specification for the ERROR packet contents
      send_ERR(sendSocket, requestedFile, 0);
      return;
    }

  }
}
