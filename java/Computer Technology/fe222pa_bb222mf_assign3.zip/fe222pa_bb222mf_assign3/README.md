 How to run this program:

First go to line 33 and 35 in TFTPServer.java and select a path to a directory for reading and writing.

If in windows, use the TFTP client and select a folder, for read requests you should take a file from that folder, and then you would find that file in the read folder, for write request just take any file located anywhere and it would be sent to the designated write folder.
use host localhost and Port 4730, if available use block size 512

Fredric 50%
Batjigdrel 50%
