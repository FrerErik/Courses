All information is located in the PDF file
Just run the python program with all the csv files in the same folder