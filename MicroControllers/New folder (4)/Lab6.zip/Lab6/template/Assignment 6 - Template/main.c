#define F_CPU 16000000

#include <avr/interrupt.h>
#include <avr/cpufunc.h>
#include <util/delay.h>
#include <stdbool.h>
#include <stdio.h>
	

#include "ADC.h"

#define BUF_SIZE 100
volatile char str_buffer[BUF_SIZE];

/*
	Read temp.
	Don't forget to call ADC_init() before calling this function.
*/
double lm35_read_temp()
{	
	return ADC_read_voltage() / 0.01;
}

// Send a string using USART
void send_log_msg(char *str)
{
	// Code required here that sends string
	// to the other end of the USART.
}

ISR(USART0_RX_vect)
{	
	// Code required here handling incoming bytes.
}

int main(void)
{	
	// Connect PORTF pin 0, i.e ADC0, to temp sensor.
	// See pinout on page 2 and MUX table on page 290. 
	ADC_init(0b00000);
	DDRB = 0xff;
		
	// Init USART here
	// Note! There are C examples in the ATmega2560 manual!
	
	// Init LCD here 
	
	sei();
			
    /* Replace with your application code */
    while (1) 
    {		
		double t = lm35_read_temp();
		sprintf(str_buffer, "%f ", t);
		send_log_msg(str_buffer);		
    }
}

