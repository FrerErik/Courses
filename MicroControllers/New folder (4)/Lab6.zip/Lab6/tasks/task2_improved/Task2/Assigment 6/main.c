
/* ;1DT301, Computer Technology I
; Date: 2021-10-28
; Author:
; Fredric Eriksson fe22pa
; Li Ang Hu lh223ng
;
; Lab number: <6>
; Title: <task2_3>
;
; Hardware: <CPU ATmega2560>
;
; Function: <this functions implements a protocol to instruct the controller to perform 5 different commands (1(1,0) text) displays text on the lcd, (2) displays logging messages, (3) turns off logging messsages, (4) displays 
temperature on the log, (5) displays temperature on the lcd>
;
; Input ports: <Com2>
;
; Output ports: <PortB, COM1>
;
; Subroutines: <if any>
; Included files: m2560def.inc
;
; Other information: <If any>.
;
; Changes in program: <Description and date>
*/

#define F_CPU 16000000

#include <avr/interrupt.h>
#include <avr/cpufunc.h>
#include <util/delay.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>


#include "ADC.h"
#include "LCDsetup.h"
#include "Console.h"


#define BAUD_PRESCALER 0x0067
#define BUF_SIZE 100
typedef enum { F, T } boolean;
volatile char str_buffer[];
volatile char temp[];
volatile int x;
/*
	Read temp.
	Don't forget to call ADC_init() before calling this function.
*/
double lm35_read_temp()
{	
	return ADC_read_voltage() / 0.01;
}


int main(void)
{	
	boolean command1;
	boolean command5;
	x = 1;
	command1 = F;
	command5 = F;
	
	char user_input;
	uint8_t index = 0;
	uint8_t tempIndex = 0;
	
	// Connect PORTF pin 0, i.e ADC0, to temp sensor.
	// See pinout on page 2 and MUX table on page 290. 
	ADC_init(0b00000);
	DDRB = 0xff;
	Console_init(BAUD_PRESCALER);
	
	Console_Send_Log_boolean("\n", x);
	Console_Send_Log_boolean("Microcontroller is up and running", x);
	
	LCD_Init();
		
	// Init USART here
	// Note! There are C examples in the ATmega2560 manual!
	
	// Init LCD here 
	
	sei();
			
    /* Replace with your application code */
    while (1) 
    {		
		// printing to line x (content)
		user_input = Console_Listener();
		
		if(user_input != '\n'  && user_input != '\r') 
		 {
			 str_buffer[index++] = user_input;
			if (index > BUF_SIZE) 
			{
				index = 0;
			}
			
		}
		
		temp[tempIndex++] = str_buffer[index];

		switch (user_input) // different protocols for different user inputs
		{
			case '1': ;
				if (str_buffer[0] == '1')
				{
					command1 = T;
					break;
				}
				break;
			case '2': ;
				if (str_buffer[0] == '2')
				{
					x = 1;
					char c[] = "log on\n";
					Console_Send_Log_boolean("\n", x);
					Console_Send_Log_boolean(c, x);	
					break;
				}
				break;
			case '3': ; 
				if (str_buffer[0] == '3')
				{
					x = 0;
					char c[] = "log off\n";
					Console_Send_Log_boolean("\n", x);
					Console_Send_Log_boolean(c, x);	
					break;
				}
				break;
			case '4': ;
				if(str_buffer[0] == '4')
				{
					double t = lm35_read_temp();
					char c[] = "";
					sprintf(c, "%f ", t);
					Console_Send_Log_boolean("\n", x);
					Console_Send_Log_boolean(c, x);	
					break;
				}
				break;
			case '5': ;
				
				if (str_buffer[0] == '5')
				{
					command5 = T;
				}
				
				
				break;
			default: ;
				//strcpy(str_buffer, "");
				break;
		}
		
		
		 
		if (user_input == '\n')
		{	
			if (command5) 
			{
				double t = lm35_read_temp();	
				sprintf(str_buffer, "%f ", t);
				index = 9;
				command5 = F;
				
				LCD_Clear();
			
				LCD_String_xy(0, 0, str_buffer);
			
				memset(str_buffer, 0, index);
				index = 0;
						
			} else if (command1) // for displaying strings
			{
				char a = str_buffer[1];
				command1 = F;
				int i = 0;
				while (i < index - 2) // to move the str_buffer two letters back
				{
					str_buffer[i] = str_buffer[i + 2];
					i++;
				}
				str_buffer[index - 2] = '\0';

				LCD_Clear();
				if (a == '1') 
				{	
					
					Console_Send_Log_boolean("\n", x);				
					char prompt[50]  = "The following string will be printed in line 1: ";
					Console_Send_Log_boolean(prompt, x);	
					Console_Send_Log_boolean(str_buffer, x);	
					LCD_String_xy(1, 0, str_buffer);
				} else if (a == '0')
				{
					Console_Send_Log_boolean("\n", x);
					char prompt[50] = "The following string will be printed in line 0: ";
					Console_Send_Log_boolean(prompt, x);	
					Console_Send_Log_boolean(str_buffer, x);	
					LCD_String_xy(0, 0, str_buffer);
				}
			
				memset(str_buffer, 0, index);
				index = 0;
			} else  // for rest of the cases
			{
				LCD_Clear();
			
				//LCD_String_xy(0, 0, str_buffer);
			
				memset(str_buffer, 0, index);
				index = 0;
			}
			
		}
    }
	
	return 1;
}


