/*
 * Console.h
 *
 * Created: 10/31/2021 6:29:10 PM
 *  Author: fredr
 */ 


#ifndef CONSOLE_H_
#define CONSOLE_H_

void Console_init(unsigned int ubrr);

void Console_Speaker(char c);

char Console_Listener(void);

void Console_Send_Log(char *ptr);

void Console_Send_Log_boolean(char *ptr, int x);

#endif /* CONSOLE_H_ */