
/*1DT301, Computer Technology I
; Date: 2021-10-28
; Author:
; Fredric Eriksson fe222pa
; Li Ang Hu lh223ng
;
; Lab number: <6>
; Title: <task1>
;
; Hardware: <CPU ATmega2560>
;
; Function: <This program is meant to take an input from a console and then display it on an lcd when the text appears then it would wait for 1 second and then fall to the second line and show the next message
if it the user adds it in time otherwise the screen would be completely cleared >
;
; Input ports: <Com2 (simulator)>
;
; Output ports: < PORTB and com1 (simulator) >
;
; Subroutines: <if any>
; Included files: m2560def.inc
;
; Other information: <If any>.
;
; Changes in program: <Description and date>
*/

#define F_CPU 16000000


#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/cpufunc.h>
#include <util/delay.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>





#include "ADC.h"
#include "LCDsetup.h"
#include "Console.h"


#define BAUD_PRESCALER 0x0067
#define BUF_SIZE 100
#define LED PD4

typedef enum { F, T, A } boolean;
volatile char str_buffer[];
int ms;

/*
	Read temp.
	Don't forget to call ADC_init() before calling this function.
*/
double lm35_read_temp()
{	
	return ADC_read_voltage() / 0.01;
}



int main(void)
{	
	boolean input = F;
	char user_input;
	uint8_t index = 0;	
	// Connect PORTF pin 0, i.e ADC0, to temp sensor.
	// See pinout on page 2 and MUX table on page 290. 
	ADC_init(0b00000);
	DDRB = 0xff;
	Console_init(BAUD_PRESCALER);
	
	LCD_Init();
		
	// Init USART here
	// Note! There are C examples in the ATmega2560 manual!
	
	// Init LCD here 
	
	
			
    /* Replace with your application code */
    while (1) 
    {		
		
		user_input = Console_Listener();
		
		
		if(user_input != '\n'  && user_input != '\r') 
		 {
			 str_buffer[index++] = user_input;
			 
			if (index > BUF_SIZE) 
			{
				index = 0;
			}
			
		}
		
		
		
		 
		if (user_input == '\n')
		{	
		
			if (input == F)
			{
				LCD_String_xy(0, 0, str_buffer);
				_delay_ms(500);
				LCD_Clear();
				LCD_String_xy(1, 0, str_buffer);
			
				_delay_ms(500);
				char temp = Console_Listener_interactive();
				if (temp == ' ') 
				{
					LCD_Clear();
					memset(str_buffer, 0, index);
					index = 0;
				} else 
				{
					input = T;
					index = 1;
					str_buffer[0] = temp;
				}
		
			} else if (input == T)
			{
				LCD_String_xy(0, 0, str_buffer);
				str_buffer[strlen(str_buffer)] = '\0';
				_delay_ms(500);
				LCD_Clear();
				LCD_String_xy(1, 0, str_buffer);
			
				_delay_ms(500);
				LCD_Clear();
			
				memset(str_buffer, 0, index);
				index = 0;
				input = F;
			}
		}



    }
	return 1;
	
	

}

